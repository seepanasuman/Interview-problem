import React, { useState } from 'react';
import axios from 'axios';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const onSubmitHandler =  (event) => {
        event.preventDefault();
         axios.post('http://localhost:8080/login', { username, password }).then(res=>{
            console.log(res.data); 
            localStorage.setItem("token",res.data.token)
         })
              
    };

    // no need to authorize each and every route we are passing token as response headers

    const getTimeapi=()=>{
        const token =localStorage.getItem("token");
        axios.post('http://localhost:8080/time',{
                headers: {
                    'Content-Type': 'application/json',
                    'token':token
                },
        })
    }
    getTimeapi();

    return (
        <div>
            <h1>Login Page</h1>
            <form onSubmit={onSubmitHandler}>
                <div>
                    <label>Username</label>
                    <input
                        type="text"
                        value={username}
                        onChange={(event) => setUsername(event.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Password</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(event) => setPassword(event.target.value)}
                        required
                    />
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    );
};

export default Login;
