const express = require('express');
const jwt = require('jsonwebtoken');
const { MongoClient } = require('mongodb');
const { v4: uuidv4 } = require("uuid");
const app = express();

app.use(express.json());
const PORT = 8080;
const JWT_SECRET_KEY = "this_is_suman_seepana";
const MAX_LOGIN_ATTEMPTS=3;
let UserDetails;
let tokenStore = {};

const LINK_VALIDITY_DURATION_MINUTES = 5;
const connectToDB = async () => {
    const url = "mongodb://localhost:27017/mydatabase"

    const client = MongoClient.connect(url);
    await client.connect();
    const database = client.db('UserInfo');
    console.log('Connected to MongoDB');
    UserDetails = database.collection('UserDetails');
}

// consider user table has username ,password,noofattempmpts,lockingperiod

//we need to check the no of times user tried and need to store in the db (No Of attempts )
//we need to check the how much time to lock the user to login (locking period)

app.post('/login', (req, res) => {

    const { username, password } = req.body;
    if (!username) {
        res.status(400).send("username should be null or undefined");
    }
    if (!password) {
        res.status(400).send("username should be null or undefined");
    }
    if (password && password.length < 5) {
        res.status(400).send("minimum 5 chracters are required for password")
    }

    const existingUser = UserDetails.find({ username: username, password: password });
    if (existingUser) {
        const token = jwt.sign(existingUser, JWT_SECRET_KEY, { expiresIn: '1hr' });
        res.status(200).send({ token: token });
    }
    else {
        attempts++;
        if (attempts >= MAX_LOGIN_ATTEMPTS) {
            res.status(403).json('Account locked due to too many login attempts');
        } 
        res.status(404).send("user not found");
    }
})

const verifyToken = (req, res, next) => {
    const token = req.headers['authorization'];
    // const token="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6InN1bWFuIiwicGFzc3dvcmQiOiJHb3V0aGFtaUAxNDMiLCJpYXQiOjE3MjE1NTU0NjV9.lu9MreiT9nh5HsZQRBrsiDl0FBMHXwFYCLKWDkYq8l4"
    jwt.verifyToken(token, JWT_SECRET_KEY).then((err, decoded) => {
        if (err) {
            res.status(401).send("auAuthorized not valid token")
        }
        else {
            const { username, password } = decoded;
            next();
        }
    })
}

app.get("/time", verifyToken, (req, res) => {
    const currentTimeStamp = new Date();
    res.status(200).send({ timeStamp: currentTimeStamp });
})




app.post('/generate-link', (req, res) => {
    const { email, phoneNumber } = req.body;

    if (!email && !phoneNumber) {
        return res.status(400).json("email or phone number should not be empty");
    }
    const userIdentifier = email || phoneNumber;

    const token = uuid.v4();
    const expiryTime = new Date(Date.now() + (LINK_VALIDITY_DURATION_MINUTES * 60 * 1000));

    tokenStore[token] = {
        userIdentifier,
        expiryTime,
    };

    const link = `http://localhost:8080/authenticate/${token}`;

    res.status(200).send({ link });
});

app.get('/authenticate/:token', (req, res) => {
    const { token } = req.params;

    if (!tokenStore[token]) {
        return res.status(400).send('Invalid token');
    }

    const tokenInfo = tokenStore[token];

    if (tokenInfo.expiryTime < new Date() || tokenInfo.used) {
        return res.status(400).send('Token expired or already used');
    }

    tokenStore[token].used = true;

    res.json({ token });
});

app.post('/kickout', (req, res) => {
    const { username } = req.body;

    for (let token in tokenStore) {
        if (tokenStore[token].username === username) {
            delete tokenStore[token];
        }
    }

    res.status(200).send( `User '${username}' kicked out successfully`);
});


app.listen(PORT, () => {
    console.log(`app is running on porty number ${PORT}`)
});

